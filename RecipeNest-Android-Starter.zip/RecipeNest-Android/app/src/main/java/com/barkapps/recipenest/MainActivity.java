package com.barkapps.recipenest;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final ArrayList<Recipe> recipes = new ArrayList<>();
    private LinearLayout list;
    private SharedPreferences prefs;
    private int ink = Color.rgb(43, 53, 43);
    private int green = Color.rgb(48, 104, 75);
    private int cream = Color.rgb(250, 248, 241);

    static class Recipe {
        String title, ingredients, steps;
        Recipe(String t, String i, String s) { title=t; ingredients=i; steps=s; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("recipenest_local", MODE_PRIVATE);
        loadRecipes();
        showHome();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(ink);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawableCompat rounded(int color) { return new GradientDrawableCompat(color, dp(16)); }

    // Small helper to keep the UI dependency-free.
    private static class GradientDrawableCompat extends android.graphics.drawable.GradientDrawable {
        GradientDrawableCompat(int color, int radius) {
            setColor(color); setCornerRadius(radius);
        }
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(18), dp(20), dp(20));
        l.setBackgroundColor(cream);
        return l;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(rounded(green));
        return b;
    }
    private void showHome() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = vertical();
        TextView brand = text("RecipeNest", 30, true);
        brand.setTextColor(green);
        root.addView(brand);
        TextView sub = text("Your recipes, gathered in one place.", 15, false);
        sub.setPadding(0, dp(4), 0, dp(18)); root.addView(sub);
        Button add = button("+ Add a recipe");
        add.setOnClickListener(v -> editRecipe(-1));
        root.addView(add, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView heading = text("My recipes", 21, true);
        heading.setPadding(0, dp(24), 0, dp(10)); root.addView(heading);
        if (recipes.isEmpty()) {
            TextView empty = text("Your recipe collection starts here. Add a favorite meal to get started.", 16, false);
            empty.setPadding(dp(16), dp(18), dp(16), dp(18));
            empty.setBackground(rounded(Color.WHITE)); root.addView(empty);
        } else {
            for (int i=0; i<recipes.size(); i++) {
                final int index = i;
                Recipe r = recipes.get(i);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(16), dp(14), dp(16), dp(14));
                card.setBackground(rounded(Color.WHITE));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
                cp.bottomMargin = dp(10); root.addView(card, cp);
                TextView title = text(r.title, 19, true); card.addView(title);
                String preview = r.ingredients.trim().isEmpty() ? "Tap to add ingredients and steps" : r.ingredients;
                TextView detail = text(preview, 14, false);
                detail.setMaxLines(2); detail.setPadding(0, dp(6), 0, dp(8)); card.addView(detail);
                Button open = button("Open recipe");
                open.setOnClickListener(v -> viewRecipe(index));
                card.addView(open, new LinearLayout.LayoutParams(-1, dp(44)));
            }
        }
        TextView footer = text("Saved on this device • No account required", 12, false);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(24), 0, dp(4)); root.addView(footer);
        scroll.addView(root); setContentView(scroll);
    }

    private void editRecipe(int index) {
        Recipe existing = index >= 0 ? recipes.get(index) : new Recipe("", "", "");
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), dp(8));
        EditText title = field("Recipe title", existing.title, false);
        EditText ingredients = field("Ingredients", existing.ingredients, true);
        EditText steps = field("Instructions / notes", existing.steps, true);
        form.addView(title); form.addView(ingredients); form.addView(steps);
        ScrollView sv = new ScrollView(this); sv.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(index >= 0 ? "Edit recipe" : "New recipe")
            .setView(sv)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String t = title.getText().toString().trim();
            if (t.isEmpty()) { title.setError("Please enter a recipe title"); return; }
            Recipe r = new Recipe(t, ingredients.getText().toString().trim(), steps.getText().toString().trim());
            if (index >= 0) recipes.set(index, r); else recipes.add(0, r);
            saveRecipes(); dialog.dismiss(); showHome();
        }));
        dialog.show();
    }

    private EditText field(String hint, String value, boolean multi) {
        EditText e = new EditText(this); e.setHint(hint); e.setText(value);
        e.setTextSize(16); e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackground(rounded(Color.WHITE));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, multi ? dp(112) : dp(56));
        p.bottomMargin = dp(10); e.setLayoutParams(p);
        if (multi) { e.setGravity(Gravity.TOP | Gravity.START); e.setSingleLine(false); }
        return e;
    }

    private void viewRecipe(int index) {
        Recipe r = recipes.get(index);
        LinearLayout body = vertical();
        TextView ingredients = text("INGREDIENTS", 13, true);
        ingredients.setTextColor(green); body.addView(ingredients);
        TextView ing = text(r.ingredients.isEmpty() ? "No ingredients added yet." : r.ingredients, 16, false);
        ing.setPadding(0, dp(6), 0, dp(18)); body.addView(ing);
        TextView steps = text("INSTRUCTIONS & NOTES", 13, true);
        steps.setTextColor(green); body.addView(steps);
        TextView st = text(r.steps.isEmpty() ? "No instructions added yet." : r.steps, 16, false);
        st.setPadding(0, dp(6), 0, dp(10)); body.addView(st);
        ScrollView sv = new ScrollView(this); sv.addView(body);
        new AlertDialog.Builder(this).setTitle(r.title).setView(sv)
            .setNeutralButton("Delete", (d,w) -> new AlertDialog.Builder(this)
                .setTitle("Delete recipe?")
                .setMessage("This removes \"" + r.title + "\" from this device.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dd,ww) -> { recipes.remove(index); saveRecipes(); showHome(); })
                .show())
            .setNegativeButton("Close", null)
            .setPositiveButton("Edit", (d,w) -> editRecipe(index))
            .show();
    }

    private void saveRecipes() {
        JSONArray a = new JSONArray();
        try {
            for (Recipe r : recipes) {
                JSONObject o = new JSONObject();
                o.put("title", r.title); o.put("ingredients", r.ingredients); o.put("steps", r.steps);
                a.put(o);
            }
            prefs.edit().putString("recipes", a.toString()).apply();
        } catch (Exception ignored) {}
    }
    private void loadRecipes() {
        String raw = prefs.getString("recipes", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i=0; i<a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                recipes.add(new Recipe(o.optString("title"), o.optString("ingredients"), o.optString("steps")));
            }
        } catch (Exception ignored) {}
    }
}
