package com.barkapps.recipenest;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(250,247,239), INK=Color.rgb(39,53,42), GREEN=Color.rgb(48,91,61),
        MINT=Color.rgb(225,237,220), MUTED=Color.rgb(113,119,104), LINE=Color.rgb(230,225,213),
        WHITE=Color.WHITE, GOLD=Color.rgb(225,174,87);
    LinearLayout root, content, bottom;
    EditText searchBox;
    ArrayList<Recipe> recipes=new ArrayList<>();
    String page="Home", query="";
    int nextId=1;
    class Recipe {
        int id; String title, category, ingredients, instructions, notes, time, emoji; boolean favorite;
        Recipe(int id,String t,String c,String ing,String ins,String n,String tm,String em,boolean f){
            this.id=id;title=t;category=c;ingredients=ing;instructions=ins;notes=n;time=tm;emoji=em;favorite=f;
        }
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        load(); render();
    }
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    GradientDrawable outline(int color,int stroke,int radius){GradientDrawable d=shape(color,radius);d.setStroke(dp(1),stroke);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,lp(1,h));}
    TextView button(String s,int bg,int fg,Runnable action){TextView t=text(s,14,fg,true);t.setGravity(Gravity.CENTER);pad(t,16,12,16,12);t.setBackground(shape(bg,16));t.setOnClickListener(v->action.run());return t;}
    void load(){String raw=getSharedPreferences("recipenest",0).getString("recipes","[]");try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);recipes.add(new Recipe(o.optInt("id"),o.optString("title"),o.optString("category","Everyday"),o.optString("ingredients"),o.optString("instructions"),o.optString("notes"),o.optString("time","25 min"),o.optString("emoji","🍲"),o.optBoolean("favorite")));nextId=Math.max(nextId,o.optInt("id")+1);}}catch(Exception ignored){} }
    void save(){JSONArray a=new JSONArray();try{for(Recipe r:recipes){JSONObject o=new JSONObject();o.put("id",r.id);o.put("title",r.title);o.put("category",r.category);o.put("ingredients",r.ingredients);o.put("instructions",r.instructions);o.put("notes",r.notes);o.put("time",r.time);o.put("emoji",r.emoji);o.put("favorite",r.favorite);a.put(o);}}catch(Exception ignored){}getSharedPreferences("recipenest",0).edit().putString("recipes",a.toString()).apply();}
    void render(){root=col();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout header=row();pad(header,22,14,22,8);
        TextView brand=text("❋  RecipeNest",22,GREEN,true);header.addView(brand,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView add=text("＋",28,WHITE,true);add.setGravity(Gravity.CENTER);add.setBackground(shape(GREEN,18));header.addView(add,lp(46,46));add.setOnClickListener(v->editRecipe(null));root.addView(header);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=col();pad(content,20,4,20,22);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(page.equals("Home"))home();else if(page.equals("My Recipes"))listing(false);else if(page.equals("Favorites"))listing(true);else settings();
        nav(); }
    void home(){
        TextView eyebrow=text("YOUR LITTLE CORNER OF THE KITCHEN",10,GREEN,true);eyebrow.setLetterSpacing(.08f);content.addView(eyebrow);gap(content,8);
        TextView title=text("What sounds\ngood today?",31,INK,true);title.setLineSpacing(dp(1),1f);content.addView(title);gap(content,7);
        content.addView(text("Keep your favorites close and make something lovely.",14,MUTED,false));gap(content,20);
        LinearLayout hero=col();pad(hero,20,18,18,18);hero.setBackground(shape(GREEN,24));
        LinearLayout hr=row();LinearLayout left=col();left.addView(text("A LITTLE INSPIRATION",10,0xFFD8E8D0,true));gap(left,8);
        TextView h=text(recipes.isEmpty()?"Start your own recipe collection":"Your kitchen, your rules",21,WHITE,true);left.addView(h);
        gap(left,7);left.addView(text(recipes.isEmpty()?"Save recipes you love, all in one place.":"Save the dishes you want to make again.",13,0xFFE1E9DD,false));
        hr.addView(left,new LinearLayout.LayoutParams(0,-2,1));TextView emoji=text("🥑",54,WHITE,false);emoji.setGravity(Gravity.CENTER);hr.addView(emoji);hero.addView(hr);
        gap(hero,16);TextView cta=button("＋   Add a recipe",0xFFF3E9D5,GREEN,()->editRecipe(null));hero.addView(cta);content.addView(hero);gap(content,24);
        LinearLayout section=row();section.addView(text("Your collection",19,INK,true),new LinearLayout.LayoutParams(0,dp(30),1));
        section.addView(text(recipes.size()+" saved",12,MUTED,false));content.addView(section);gap(content,12);
        searchBox=new EditText(this);searchBox.setSingleLine(true);searchBox.setTextSize(14);searchBox.setHint("⌕   Search recipes or ingredients");searchBox.setHintTextColor(MUTED);searchBox.setTextColor(INK);searchBox.setBackground(outline(WHITE,LINE,15));pad(searchBox,14,2,14,2);content.addView(searchBox,lp(-1,50));searchBox.setText(query);
        searchBox.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();refreshCards();}public void afterTextChanged(android.text.Editable e){}});
        gap(content,20);TextView recent=text("Recently saved",18,INK,true);content.addView(recent);gap(content,10);
        LinearLayout cards=col();cards.setTag("cards");content.addView(cards);fillCards(cards,false);
    }
    void refreshCards(){View v=content.findViewWithTag("cards");if(v instanceof LinearLayout)fillCards((LinearLayout)v,false);}
    void listing(boolean fav){content.addView(text(fav?"THE KEEPERS":"YOUR RECIPE BOX",10,GREEN,true));gap(content,8);content.addView(text(fav?"Favorites":"My recipes",29,INK,true));gap(content,6);content.addView(text(fav?"The ones worth making again.":"Every recipe you’ve saved, together.",14,MUTED,false));gap(content,18);
        EditText s=new EditText(this);s.setSingleLine(true);s.setTextSize(14);s.setHint("⌕   Search your collection");s.setTextColor(INK);s.setHintTextColor(MUTED);s.setBackground(outline(WHITE,LINE,15));pad(s,14,2,14,2);content.addView(s,lp(-1,50));s.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence a,int b,int c,int d){}public void onTextChanged(CharSequence a,int b,int c,int d){LinearLayout list=(LinearLayout)content.findViewWithTag("list");fillCards(list,fav,a.toString());}public void afterTextChanged(android.text.Editable e){}});
        gap(content,16);LinearLayout list=col();list.setTag("list");content.addView(list);fillCards(list,fav,"");}
    void fillCards(LinearLayout target,boolean fav){fillCards(target,fav,query);}
    void fillCards(LinearLayout target,boolean fav,String q){target.removeAllViews();int count=0;ArrayList<Recipe> list=new ArrayList<>(recipes);Collections.reverse(list);
        for(Recipe r:list){if(fav&&!r.favorite)continue;String hay=(r.title+" "+r.ingredients+" "+r.category).toLowerCase(Locale.ROOT);if(q!=null&&!q.trim().isEmpty()&&!hay.contains(q.trim().toLowerCase(Locale.ROOT)))continue;target.addView(recipeCard(r));gap(target,10);count++;}
        if(count==0){LinearLayout empty=col();empty.setGravity(Gravity.CENTER);pad(empty,20,24,20,24);empty.setBackground(outline(WHITE,LINE,20));TextView icon=text(fav?"♡":"🥣",34,GREEN,true);icon.setGravity(Gravity.CENTER);empty.addView(icon);gap(empty,8);TextView title=text(fav?"No favorites yet":"Your recipe box is waiting",17,INK,true);title.setGravity(Gravity.CENTER);empty.addView(title);gap(empty,6);TextView desc=text(fav?"Tap the heart on any recipe to keep it here.":"Add your first recipe and it’ll appear here.",13,MUTED,false);desc.setGravity(Gravity.CENTER);empty.addView(desc);gap(empty,14);empty.addView(button("＋  Add a recipe",GREEN,WHITE,()->editRecipe(null)));target.addView(empty);}
    }
    View recipeCard(Recipe r){LinearLayout card=row();card.setBackground(outline(WHITE,LINE,20));pad(card,12,12,12,12);
        TextView art=text(r.emoji,34,INK,false);art.setGravity(Gravity.CENTER);art.setBackground(shape(r.category.equalsIgnoreCase("Dessert")?0xFFF8E7D8:r.category.equalsIgnoreCase("Breakfast")?0xFFF5E9BD:MINT,16));card.addView(art,lp(76,82));
        LinearLayout info=col();pad(info,12,0,4,0);info.addView(text(r.category.toUpperCase(Locale.ROOT),9,GREEN,true));gap(info,5);TextView title=text(r.title,16,INK,true);title.setMaxLines(2);info.addView(title);gap(info,6);info.addView(text("◷  "+r.time,12,MUTED,false));card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        TextView heart=text(r.favorite?"♥":"♡",23,r.favorite?0xFFCE6D59:MUTED,true);heart.setGravity(Gravity.CENTER);card.addView(heart,lp(34,44));heart.setOnClickListener(v->{r.favorite=!r.favorite;save();render();});card.setOnClickListener(v->details(r));return card;
    }
    void details(Recipe r){LinearLayout box=col();pad(box,22,8,22,8);TextView art=text(r.emoji,48,INK,false);art.setGravity(Gravity.CENTER);box.addView(art);gap(box,8);box.addView(text(r.category+"  ·  "+r.time,12,GREEN,true));gap(box,8);box.addView(text(r.title,25,INK,true));gap(box,14);box.addView(text("INGREDIENTS",11,GREEN,true));gap(box,5);box.addView(text(r.ingredients.isEmpty()?"No ingredients added yet.":r.ingredients,15,INK,false));gap(box,14);box.addView(text("METHOD",11,GREEN,true));gap(box,5);box.addView(text(r.instructions.isEmpty()?"No instructions added yet.":r.instructions,15,INK,false));if(!r.notes.isEmpty()){gap(box,12);box.addView(text("NOTES",11,GREEN,true));gap(box,4);box.addView(text(r.notes,14,MUTED,false));}
        ScrollView sc=new ScrollView(this);sc.addView(box);AlertDialog d=new AlertDialog.Builder(this).setView(sc).setPositiveButton("Done",null).setNeutralButton("Share / export",(di,w)->shareRecipe(r)).setNegativeButton("Edit",(di,w)->editRecipe(r)).create();d.show();d.getWindow().setBackgroundDrawable(shape(BG,24));}
    void editRecipe(Recipe existing){final Recipe old=existing;ScrollView scroll=new ScrollView(this);LinearLayout form=col();pad(form,22,8,22,12);scroll.addView(form);
        form.addView(text(old==null?"A new favorite":"Edit recipe",24,INK,true));gap(form,14);
        EditText title=field("Recipe name",old==null?"":old.title);form.addView(title);gap(form,10);
        EditText category=field("Category (e.g. Dinner, Dessert)",old==null?"Dinner":old.category);form.addView(category);gap(form,10);
        EditText emoji=field("Food emoji (e.g. 🍝)",old==null?"🍲":old.emoji);form.addView(emoji);gap(form,10);
        EditText time=field("Prep / cook time (e.g. 25 min)",old==null?"25 min":old.time);form.addView(time);gap(form,10);
        EditText ingredients=field("Ingredients — one per line",old==null?"":old.ingredients);ingredients.setMinLines(3);ingredients.setGravity(Gravity.TOP);form.addView(ingredients);gap(form,10);
        EditText instructions=field("Instructions",old==null?"":old.instructions);instructions.setMinLines(4);instructions.setGravity(Gravity.TOP);form.addView(instructions);gap(form,10);
        EditText notes=field("Notes (optional)",old==null?"":old.notes);notes.setMinLines(2);form.addView(notes);
        AlertDialog dialog=new AlertDialog.Builder(this).setView(scroll).setPositiveButton(old==null?"Save recipe":"Save changes",null).setNegativeButton("Cancel",null).create();dialog.setOnShowListener(x->{dialog.getButton(-1).setTextColor(GREEN);dialog.getButton(-1).setOnClickListener(v->{String name=title.getText().toString().trim();if(name.isEmpty()){title.setError("Add a recipe name");return;}if(old==null)recipes.add(new Recipe(nextId++,name,nonblank(category,"Dinner"),nonblank(ingredients,""),nonblank(instructions,""),nonblank(notes,""),nonblank(time,"25 min"),nonblank(emoji,"🍲"),false));else{old.title=name;old.category=nonblank(category,"Dinner");old.emoji=nonblank(emoji,"🍲");old.time=nonblank(time,"25 min");old.ingredients=nonblank(ingredients,"");old.instructions=nonblank(instructions,"");old.notes=nonblank(notes,"");}save();dialog.dismiss();page="Home";query="";render();});});dialog.show();dialog.getWindow().setBackgroundDrawable(shape(BG,24));}
    String nonblank(EditText e,String fallback){String s=e.getText().toString().trim();return s.isEmpty()?fallback:s;}
    EditText field(String hint,String val){EditText e=new EditText(this);e.setText(val);e.setHint(hint);e.setTextColor(INK);e.setHintTextColor(MUTED);e.setTextSize(14);e.setPadding(dp(14),dp(10),dp(14),dp(10));e.setBackground(outline(WHITE,LINE,14));return e;}
    void shareRecipe(Recipe r){String s=r.title+"\\n"+r.category+" · "+r.time+"\\n\\nINGREDIENTS\\n"+r.ingredients+"\\n\\nINSTRUCTIONS\\n"+r.instructions+(r.notes.isEmpty()?"":"\\n\\nNOTES\\n"+r.notes);Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,r.title);i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Export recipe"));}
    void settings(){content.addView(text("YOUR APP",10,GREEN,true));gap(content,8);content.addView(text("Settings",29,INK,true));gap(content,8);content.addView(text("Your recipes are stored on this device.",14,MUTED,false));gap(content,20);
        LinearLayout card=col();pad(card,18,16,18,16);card.setBackground(outline(WHITE,LINE,20));card.addView(text("RecipeNest",18,INK,true));gap(card,6);card.addView(text("Version 1.1 · Local recipe collection",13,MUTED,false));gap(card,16);card.addView(text("Your data stays on this phone. Use Share / export on a recipe to send a text copy to another app.",14,INK,false));content.addView(card);gap(content,16);
        content.addView(button("Export all recipes",GREEN,WHITE,()->{if(recipes.isEmpty()){new AlertDialog.Builder(this).setMessage("Add a recipe first, then you can export it.").setPositiveButton("OK",null).show();return;}StringBuilder b=new StringBuilder("RecipeNest — My Recipes\\n\\n");for(Recipe r:recipes)b.append(r.title).append("\\n").append(r.category).append(" · ").append(r.time).append("\\nINGREDIENTS\\n").append(r.ingredients).append("\\nINSTRUCTIONS\\n").append(r.instructions).append("\\n\\n");Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"My RecipeNest recipes");i.putExtra(Intent.EXTRA_TEXT,b.toString());startActivity(Intent.createChooser(i,"Export recipe collection"));}));gap(content,12);
        content.addView(button("Delete all recipes",0xFFF6E5E0,0xFF9A4032,()->new AlertDialog.Builder(this).setTitle("Delete all recipes?").setMessage("This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{recipes.clear();save();render();}).show()));
    }
    void nav(){bottom=row();bottom.setBackgroundColor(WHITE);bottom.setElevation(dp(8));String[] names={"Home","My Recipes","Favorites","Settings"};String[] icons={"⌂","▤","♡","⚙"};for(int i=0;i<names.length;i++){final String n=names[i];LinearLayout item=col();item.setGravity(Gravity.CENTER);pad(item,2,9,2,8);TextView ic=text(icons[i],21,page.equals(n)?GREEN:MUTED,true);ic.setGravity(Gravity.CENTER);item.addView(ic);TextView label=text(names[i],10,page.equals(n)?GREEN:MUTED,page.equals(n));label.setGravity(Gravity.CENTER);item.addView(label);item.setOnClickListener(v->{page=n;query="";render();});bottom.addView(item,new LinearLayout.LayoutParams(0,dp(60),1));}root.addView(bottom);}
    @Override public void onBackPressed(){if(!page.equals("Home")){page="Home";query="";render();}else super.onBackPressed();}
}
